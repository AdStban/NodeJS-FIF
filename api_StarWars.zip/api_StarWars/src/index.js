/**
 * Index, donde tenemos los llamados a las demas funciones y objetos
 */
const express = require("express");
const bodyParser = require("body-parser");
const getStarships = require("./getStarships");
//const getUrl = require('./getUrl');
//const getDataType = require('./getType');
//const filterStarship = require('./filterStarships');
const insertData = require('./insertData');
const conection = require('./conectionDB');
//const getData = require('./getData');


const app = express();
const PORT = 3000;

app.use(bodyParser.json());

app.post("/ruta-1",(req,res, next)=> {
    console.log(req.body);
    res.status(200);
    res.end;    
});

app.post("/ruta-2", async (req,res)=>{
    
    const result = await getStarships();
    conection;
    //const resultado = result[res.params.index];
    insertData(result);
    //console.log(`el resultado es: `,result);
    
    res.json(result);
});

app.listen(PORT,()=>{
    console.log(`App started on port: ${ PORT }`);
});