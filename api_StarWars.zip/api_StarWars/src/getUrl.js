const getUrl= (results)=>{ 
    //generar arreglo con la url de la api StarWars
    let link =[]
    for (let contador = 0; contador < results.length; contador++){        
        link.push(results[contador]['url']);       
    }    
    console.log[link[0]];
    return link;
}

module.exports=getUrl;