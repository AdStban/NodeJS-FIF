/**
 * Filtro, para obtener los nombres de las naves
 */
const filterStarships =  (starships,filter)=>{
    const result = starships
    .filter(starship =>{
        return starship[filter.name] === filter.value;
    })
    .map(starship => {
        return {
            name : starship.name,
            [filter.name] : filter.value
        }
    });
    return result;
};
module.exports = filterStarships;