//const axios = require('axios');

const insertData = async (starship)=>{
    const obj = starship;
    const json = await JSON.stringify(obj);

    for (let index = 0; index < starship; index++) {
        client.set(starship.name, json, redis.print);
        console.log(`SE ESTA INSERTANDO: ${json}`);
    }
// forEach(element => {
//     client.set(element.name, json, redis.print);
// });
}


module.exports = insertData;