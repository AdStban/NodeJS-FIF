/**
 * getStarships, capturamos las naves desde la api
 */
// const axios = require('axios');
// const getStarships = async()=>{
//     const response = await axios.get('https://swapi.co/api/starships/?page=1');
//     const { results } = response.data;
//     return results; 
// };
const axios = require('axios');
const getStarships = async () => {
    const proms = [];
    for (let i = 1; i <= 4; i += 1) {
      proms.push(axios.get(`https://swapi.co/api/starships/?page=${i}`));
    }
    const res = await Promise.all(proms);
    const datas = res.map((r) => r.data.results);
    const x = [];
    for (let i = 0; i < datas.length; i += 1) {
      x.push(...datas[i]);
    }
    console.log(x);
  };

module.exports = getStarships;