const axios = require('axios');

const getDataType = async (direcciones)=> {
    
    const enlace = await direcciones[0];
        
    const { data } = await axios.get(enlace);
    
    const { types } = await data;
    
    let type = []
    for (let index=0;index< types.length;index++){

        type.push(types[index]['type']['name']);
        
    }
    console.log(type);
    return type;     
}

module.exports=getDataType;